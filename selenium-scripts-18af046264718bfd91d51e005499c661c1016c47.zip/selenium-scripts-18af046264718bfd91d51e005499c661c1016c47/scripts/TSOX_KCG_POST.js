const assert = require('assert');
const webdriver = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome');
const {getTextFromFile} = require("./read-file.js");
const By = webdriver.By;

var driver;
// Explicitly point to the chromedriver executable, because it is not in the system PATH
var service = new chrome.ServiceBuilder('node_modules\\chromedriver\\bin\\chromedriver.exe').build();
chrome.setDefaultService(service);

let myPrice = getTextFromFile("../PRICE.txt");
let myPwd = getTextFromFile("../PASS.txt");

describe('ICE BondPoint Login Page', async function() {
  this.timeout(30000);

  before(async function() {
    this.timeout(30000);
    
    driver = await new webdriver.Builder().forBrowser('chrome').build();
    await driver.get('https://demo.bondpoint.com/index.jsp');
    await driver.sleep(2000);
  });
  
  after(async function() {
    //await driver.quit();
  });
  
  it('Has the expected title value', async function() {
    let promise = await driver.getTitle();
    await assert.equal(promise, 'BondPoint :: Comprehensive Fixed-Income Solutions');
  });
  
  it('Properly enters the Username', async function() {
    let userName = await driver.findElement(webdriver.By.name('USER'));
    await userName.sendKeys('BLOOMBERGBID');
    let enteredText = await userName.getAttribute('value');
    await assert.equal(enteredText, 'BLOOMBERGBID');
  });

  it('Properly enters the Password', async function() {
    let password = await driver.findElement(webdriver.By.name('PASSWORD'));
    await password.sendKeys(myPwd);
    let enteredText = await password.getAttribute('value');
    await assert.equal(enteredText, myPwd);
  });

  it('Logs the User In Correctly', async function() {
    let userName = await driver.findElement(webdriver.By.name('USER'));
    await userName.sendKeys(webdriver.Key.ENTER);
    await driver.sleep(5000);
    let promise = await driver.getTitle();
    await assert.equal(promise, 'Browser Upgrade');
    await driver.sleep(5000);
  });

  it('Finds the button Continue Browswer and clicks it', async function() {
    let buttonContinue = await driver.findElement(webdriver.By.name('continueVB'));
    await buttonContinue.click();
    await driver.sleep(5000);
  });

  it('Verifies the website is BondPoint Offerings Page', async function() {
    let promise = await driver.getTitle();
    await assert.equal(promise, 'Offerings');
    await driver.sleep(5000);
  });

  it('Finds and hovers on menu item called "TRADING" and chooses "OFFER BONDS"', async function() {
    let dropDownMenu = await driver.findElement(webdriver.By.name('mm_trade'));
    let action = driver.actions({bridge: true});
    await action
      .move({origin:dropDownMenu, x:0, y:0})
      .perform();
    await driver.sleep(5000); //to make it hover
    await driver.findElement(webdriver.By.xpath('//*[@id="layTradingNav"]/table/tbody/tr[3]/td/a')).click();
    await driver.sleep(5000);
  })

  it('Finds the field CUSIP and enters value', async function() {
    let cusip = await driver.findElement(webdriver.By.name('cusip0'));
    await cusip.sendKeys('437076BX9');
    let enteredCusip = await cusip.getAttribute('value');
    await assert.equal(enteredCusip, '437076BX9');
    await driver.sleep(5000);
  });

  it('Finds the field Quantity and enters value', async function() {
    let qty = await driver.findElement(webdriver.By.name('qty0'));
    await qty.sendKeys('800');
    let enteredQty = await qty.getAttribute('value');
    await assert.equal(enteredQty, '800');
    await driver.sleep(5000);
  });

  it('Finds the field Min Quantity and enters value', async function() {
    let minQty = await driver.findElement(webdriver.By.name('minQty0'));
    await minQty.sendKeys('5');
    await driver.sleep(1000);
    await minQty.clear();
    await driver.sleep(1000);
    await minQty.sendKeys('5');
    let enteredMinQty = await minQty.getAttribute('value');
    await assert.equal(enteredMinQty, '5');
    await driver.sleep(5000);
  });

  it('Finds the field Price and enters value', async function() {
    let price = await driver.findElement(webdriver.By.name('price0'));
    await price.sendKeys(myPrice);
    let enteredPrice = await price.getAttribute('value');
    //await assert.equal(enteredPrice, myPrice);
    await driver.sleep(5000);
  });

  it('Finds the field Execution and enters value', async function() {
    let execution = await driver.findElement(webdriver.By.name('executionType0'));
    await execution.sendKeys('Auto-Execute');
    await driver.sleep(5000);
  });

  it('Finds the field Inventory and enters value', async function() {
    let inventory = await driver.findElement(webdriver.By.name('owner0'));
    await inventory.sendKeys('BLOOMBERGBID');
    let enteredInventory = await inventory.getAttribute('value');
    await assert.equal(enteredInventory, 'BLOOMBERGBID');
    await driver.sleep(5000);
  });

  it('Finds the field Clearing Info and enters value', async function() {
    let clearingInfo = await driver.findElement(webdriver.By.name('clearingName0'));
    await clearingInfo.sendKeys('CHASBB01');
    let enteredClearingInfo = await clearingInfo.getAttribute('value');
    await driver.sleep(5000);
  });

  it('Finds the button PREVIEW and clicks it', async function() {
    let buttonPreview = await driver.findElement(webdriver.By.xpath('/html/body/div/table[2]/tbody/tr[3]/td[3]/input'));
    await buttonPreview.click();
    await driver.sleep(5000);
  });

  it('Finds the button SUBMIT and clicks it', async function() {
    let buttonSubmit = await driver.findElement(webdriver.By.id('submitBtn'));
    await buttonSubmit.click();
    await driver.sleep(5000);
  });

});