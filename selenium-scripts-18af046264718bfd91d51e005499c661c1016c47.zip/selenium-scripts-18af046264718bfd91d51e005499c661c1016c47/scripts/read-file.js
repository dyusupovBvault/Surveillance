const fs = require('fs');
const path = require('path');

function getTextFromFile(filename) {
  let filePath = path.join(__dirname, filename);
  console.log(filePath);
  if (fs.existsSync(filePath)) {
    let contents = fs.readFileSync(filePath, 'utf8');
    return contents;
  }
  else {
    return "failed-to-read-file";
  }
};

module.exports = { getTextFromFile };